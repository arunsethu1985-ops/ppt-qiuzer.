import AdmZip from 'adm-zip';

export const config={maxDuration:60};
function decodeXml(s){return s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&')}
function slideText(xml){return [...xml.matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/g)].map(m=>decodeXml(m[1])).join(' ').replace(/\s+/g,' ').trim()}
function slidesFromPptx(base64){
 const buffer=Buffer.from(base64,'base64');if(buffer.length>10*1024*1024)throw Error('PPTX exceeds 10 MB');
 const zip=new AdmZip(buffer);const entries=zip.getEntries();if(entries.length>3000)throw Error('Too many files in PPTX');
 const paths=entries.map(e=>e.entryName).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a,b)=>Number(a.match(/slide(\d+)/)[1])-Number(b.match(/slide(\d+)/)[1]));
 if(!paths.length)throw Error('No PowerPoint slides found');if(paths.length>45)throw Error('Please upload a presentation with up to 45 slides');
 let imagesAdded=0,bytesAdded=0;
 return paths.map((path,i)=>{
   const number=Number(path.match(/slide(\d+)/)[1]);const xml=zip.getEntry(path).getData().toString('utf8');const text=slideText(xml).slice(0,4000);
   const relPath=`ppt/slides/_rels/slide${number}.xml.rels`;const rel=zip.getEntry(relPath)?.getData().toString('utf8')||'';
   const imageIds=[...xml.matchAll(/r:embed="(rId\d+)"/g)].map(m=>m[1]);const images=[];
   for(const id of [...new Set(imageIds)].slice(0,5)){
     const tag=[...rel.matchAll(/<Relationship\b[^>]*\/>/g)].map(m=>m[0]).find(t=>new RegExp(`\\bId="${id}"`).test(t));if(!tag)continue;
     const target=tag.match(/\bTarget="([^"]+)"/)?.[1];if(!target||!target.match(/\.(png|jpg|jpeg|webp)$/i))continue;
     let name=target.startsWith('/')?target.slice(1):`ppt/slides/${target}`;const segments=[];for(const part of name.split('/')){if(part==='..')segments.pop();else if(part!=='.')segments.push(part)}name=segments.join('/');
     const entry=zip.getEntry(name);if(!entry)continue;const raw=entry.getData();if(raw.length>2*1024*1024||imagesAdded>=15||bytesAdded+raw.length>12*1024*1024)continue;
     const ext=name.split('.').at(-1).toLowerCase();images.push({type:'image_url',image_url:{url:`data:image/${ext==='jpg'?'jpeg':ext};base64,${raw.toString('base64')}`,detail:'low'}});imagesAdded++;bytesAdded+=raw.length;
   }
   return {number:i+1,text,images};
 });
}
function typeFrom(instruction,type){if(type==='single')return 'single';if(type!=='auto')return type;return /(?:10|ten|complete|full|3 mcq)/i.test(instruction)?'mixed':'single'}
export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});
 try{
  if(!process.env.OPENAI_API_KEY)return res.status(500).json({error:'Set OPENAI_API_KEY in Vercel environment variables.'});
  const {fileBase64,instruction='',type='auto',avoid=[]}=req.body||{};
  if(typeof fileBase64!=='string'||fileBase64.length>14e6)return res.status(400).json({error:'Upload a PPTX under 10 MB.'});
  const slides=slidesFromPptx(fileBase64);const mode=typeFrom(instruction,type);
  if(slides.every(s=>!s.text&&!s.images.length))return res.status(422).json({error:'No readable slide text or supported images found. Convert the PPT to PPTX with PNG/JPG slide images.'});
  const content=[{type:'text',text:`You are a strict PPT-grounded quiz generator. User instruction: ${String(instruction).slice(0,600)}. Mode: ${mode}. ALWAYS use ONLY information visible in the supplied slides. NEVER invent questions, answers, terminology, details, or slide citations. Each question must be directly answerable from a specific slide. Include slide number and a short VERBATIM supporting evidence snippet from that slide (text or visible image). If there is insufficient evidence, return fewer questions. Do not repeat these questions: ${JSON.stringify(avoid).slice(0,3000)}. Return JSON object with ONLY "questions":array; question item shape {"type":"mcq|one_word|short|long","question":string,"options":string[] (4 options only for mcq; [] otherwise),"correctIndex":number (0-3 for mcq, -1 otherwise),"answer":string,"explanation":string,"slide":number,"evidence":string}. ${mode==='mixed'?'Aim for exactly ten questions in order: 3 mcq, 2 one_word, 2 short, 3 long.':mode==='single'?'Exactly ONE question.':`Generate exactly ONE question of type ${mode}.`} Ensure MCQ has only one valid answer. Match student name from instruction when naturally appropriate. Slides follow:`}];
  for(const slide of slides){content.push({type:'text',text:`SLIDE ${slide.number}\nTEXT: ${slide.text||'[No selectable text; inspect slide image if provided]'}`});content.push(...slide.images)}
  const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',temperature:0.3,response_format:{type:'json_object'},messages:[{role:'system',content:'Follow PPT source grounding rigorously; return only valid JSON.'},{role:'user',content}],max_tokens:3400}),signal:AbortSignal.timeout(55000)});
  const payload=await response.json();if(!response.ok)throw Error(payload.error?.message||'AI request failed');
  const parsed=JSON.parse(payload.choices?.[0]?.message?.content||'{}');
  const allowed=new Set(['mcq','one_word','short','long']);const questions=(Array.isArray(parsed.questions)?parsed.questions:[]).filter(q=>allowed.has(q.type)&&typeof q.question==='string'&&typeof q.answer==='string'&&Number.isInteger(q.slide)&&q.slide>=1&&q.slide<=slides.length&&typeof q.evidence==='string'&&q.evidence.trim()&&(q.type!=='mcq'||Array.isArray(q.options)&&q.options.length===4&&Number.isInteger(q.correctIndex)&&q.correctIndex>=0&&q.correctIndex<4)).slice(0,mode==='mixed'?10:1);
  if(!questions.length)throw Error('Could not generate questions supported by the PPT. Try another presentation with more readable slide content.');
  return res.status(200).json({questions,slideCount:slides.length});
 }catch(e){return res.status(400).json({error:e.message||'Could not process presentation'})}
}
