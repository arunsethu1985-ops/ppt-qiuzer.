const $=id=>document.getElementById(id);
let questions=[],index=0,uploadedData='',student='';
$('pptFile').addEventListener('change',()=>{$('fileLabel').textContent=$('pptFile').files[0]?.name||'Choose your PowerPoint (.pptx)'});
function readBase64(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result.split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file)})}
async function generate(){
 const file=$('pptFile').files[0];if(!file){$('status').textContent='Please upload a .pptx file first.';return}
 if(!file.name.toLowerCase().endsWith('.pptx')){$('status').textContent='Please upload a .pptx file (not .ppt).';return}
 if(file.size>10*1024*1024){$('status').textContent='File must be under 10 MB.';return}
 $('generateBtn').disabled=true;$('status').textContent='Reading slides and generating grounded questions...';
 try{uploadedData=await readBase64(file);await requestQuiz(false)}catch(e){$('status').textContent=e.message||'Something went wrong.'}finally{$('generateBtn').disabled=false}
}
async function requestQuiz(single){
 const instruction=$('instruction').value.trim()||'Give one question based only on the PPT';
 student=(instruction.match(/(?:for|give)\s+([A-Z][a-z]+)\b/i)||[])[1]||'';
 const resp=await fetch('/api/quiz',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({fileBase64:uploadedData,instruction:single?instruction+' Give only ONE NEW question.':instruction,type:single?'single':$('quizType').value,avoid:single?questions.map(q=>q.question).slice(-20):[]})});
 const result=await resp.json();if(!resp.ok)throw Error(result.error||'Unable to create quiz.');
 if(!Array.isArray(result.questions)||!result.questions.length)throw Error('No slide-supported questions could be generated.');
 questions=single? [...questions,...result.questions]:result.questions;index=single?questions.length-1:0;
 $('quizPanel').classList.remove('hidden');$('status').textContent=`Ready: ${result.slideCount} slides examined.`;render();$('quizPanel').scrollIntoView({behavior:'smooth'});
}
function render(){const q=questions[index];$('progress').textContent=`Question ${index+1} of ${questions.length}`;$('studentName').textContent=student?`For ${student}`:'PPT quiz';$('progressFill').style.width=`${(index+1)/questions.length*100}%`;$('questionType').textContent=({mcq:'Choose the correct answer',one_word:'One word',short:'Short answer',long:'Answer the following'})[q.type]||'Question';$('questionText').textContent=q.question;$('feedback').className='feedback hidden';$('checkBtn').disabled=false;$('nextBtn').classList.add('hidden');$('textAnswer').value='';$('options').replaceChildren();const mcq=q.type==='mcq';$('textAnswerLabel').classList.toggle('hidden',mcq);if(mcq){(q.options||[]).forEach((option,i)=>{const label=document.createElement('label');label.className='option';const radio=document.createElement('input');radio.type='radio';radio.name='answer';radio.value=String(i);label.append(radio,document.createTextNode(option));$('options').append(label)})}$('source').textContent=`Source: Slide ${q.slide} · ${q.evidence||'PPT source'}`}
$('checkBtn').addEventListener('click',()=>{const q=questions[index];let right=null;let response='';if(q.type==='mcq'){const selected=document.querySelector('input[name=answer]:checked');if(!selected)return;response=q.options[Number(selected.value)]||'';right=Number(selected.value)===q.correctIndex}else{response=$('textAnswer').value.trim();if(!response)return}const fb=$('feedback');fb.className='feedback '+(right===true?'good':right===false?'bad':'');fb.textContent=(right===true?'✓ Correct!\n':right===false?'Not quite.\n':'Your answer: '+response+'\n\n')+'Suggested answer: '+q.answer+'\n\nExplanation: '+q.explanation;$('checkBtn').disabled=true;$('nextBtn').classList.toggle('hidden',index===questions.length-1)});
$('nextBtn').addEventListener('click',()=>{if(index<questions.length-1){index++;render()}});
$('newBtn').addEventListener('click',async()=>{if(!uploadedData){$('status').textContent='Upload a PPTX first';return} $('newBtn').disabled=true;try{await requestQuiz(true)}catch(e){$('status').textContent=e.message}finally{$('newBtn').disabled=false}});
$('generateBtn').addEventListener('click',generate);
