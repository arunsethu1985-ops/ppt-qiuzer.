# SlideSpark — PowerPoint Quiz

Upload a PPTX and generate questions one by one using slide content. Supports embedded PNG/JPG/WebP images and editable slide text (within the processing limits). Gives slide source and suggested answers.

## Deploy with GitHub and Vercel
1. Create a GitHub repository, and upload all files in this folder (including `api/quiz.js`).
2. In Vercel, **Add New → Project → Import Git Repository**.
3. Keep framework **Other**, project root `./`, and deploy.
4. In Vercel **Project Settings → Environment Variables**, add `OPENAI_API_KEY` with your own OpenAI API key. Optionally set `OPENAI_MODEL` (defaults to `gpt-4o-mini`). Redeploy.
5. Open your Vercel URL and upload a `.pptx`.

This app uses paid OpenAI API usage and needs an API key; a ChatGPT subscription does not automatically include API credits.

## Local development
Install dependencies with `npm install`; run `npx vercel dev` with the environment variable configured.

## Important
- `.pptx` only, maximum 10 MB and 45 slides. Up to 15 embedded images (12 MB total after extraction) are sent for vision analysis. Limitations can affect image-heavy presentations.
- Source snippets are AI generated from the presentation; check slide citations for accuracy.
- In this starter version, multiple choice is graded automatically. Text answers display a model answer for learner review, rather than claiming a fully reliable auto-grade.
- Presentations are sent to OpenAI for processing. Do not upload sensitive content without permission.
- API key stays server-side; never place it in front-end JavaScript or commit it to GitHub.
